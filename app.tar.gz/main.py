import flet as ft
from time import sleep, localtime
from datetime import datetime
from random import randint, choice

# ==== Глобальные переменные ====

# список с игровыми слогами
game_world_list = [
	"АБ", "АВ", "АГ", "АД", "АЖ", "ЛЕ", "ЛИ", "ЛО", "ЛУ", "ЛЫ", "АЗ", "АЙ", "АК", "АЛ", "АМ",
	"ЛЮ", "ЛЯ", "МА", "МЕ", "МИ", "АН", "АП", "АР", "АС", "АТ", "МО", "МУ", "МЯ", "НА", "НЕ",
	"АЦ", "АЧ", "АШ", "БА", "БЕ", "НИ", "НО", "НУ", "НЫ", "НЯ", "БО", "БУ", "БЫ", "ВА", "ВЕ",
	"ОБ", "ОВ", "ОГ", "ОД", "ОЗ", "ВИ", "ВО", "ВУ", "ВЫ", "ВЯ", "ОЙ", "ОК", "ОЛ", "ОМ", "ОН",
	"ГА", "ГИ", "ГО", "ГУ", "ДА", "ОП", "ОР", "ОС", "ОТ", "ОХ", "ДЕ", "ДИ", "ДО", "ДЯ", "ЕВ",
	"ОЧ", "ПА", "ПЕ", "ПИ", "ПО", "ЕД", "ЕЖ", "ЕЗ", "ЕК", "ЕЛ", "ПУ", "РА", "РЕ", "РИ", "РО",
	"ЕМ", "ЕН", "ЕП", "ЕР", "ЕС", "РУ", "РЫ", "СА", "СЕ", "СИ", "ЕТ", "ЖА", "ЖЕ", "ЖИ", "ЖО",
	"СК", "СЛ", "СВ", "СТ", "СУ", "ЗА", "ЗЕ", "ЗИ", "ЗО", "ИВ", "СЫ", "СЯ", "ТА", "ТЕ", "ТИ",
	"ИГ", "ИЗ", "ИК", "ИЛ", "ИМ", "ТО", "ТУ", "ТЫ", "ТЯ", "УБ", "ИН", "ИР", "ИС", "ИТ", "ИЧ",
	"УВ", "УГ", "УД", "УЖ", "УЗ", "КА", "КИ", "КО", "КУ", "ЛА", "УК", "УЛ", "УМ", "УН", "УП",
	"УР", "УС", "УТ", "УХ", "УЧ", "УШ", "ФА", "ФЕ", "ФИ", "ФО", "ХА", "ХО", "ПР", "ЦА", "ЦЕ",
	"ЧА", "ЧЕ", "ЧИ", "ЧУ", "ША", "ШЕ", "ШИ", "ЩА", "ЩЕ", "ЩИ", "ЩУ", "ЮД", "ЮЛ", "ЮР", "ЮТ",
	"ЯВ", "ЯЗ", "ЯЛ", "ЯН", "ЯР", "ЯС", "ЯД", "ЫБ", "БИ", "РЫ", "СП", "КН", "МН", "СТ", "ПЛ",
	"ЗЛ", "КЛ", "СЦ", "ВЛ"]

# текст подсказки
help_text = (
		"   Правила очень простые: берём небольшой\n" +
		"предмет, например маленький мячик, который\n" +
		"условно будет \"бомбой\". Её передаём по\n" +
		"кругу (от игрока к игроку), причём, чтобы\n" +
		"передать бомбу, нужно назвать любое слово\n" +
		"(существительное, но не имя собственное),\n" +
		"где встречается заданный на экране слог.\n" +
		"Например, на слог \"ГА\" игроки по очереди\n" +
		"называют: ГАЛЕРА, НОГА, ПУГАЛО и т.д.,\n" +
		"главное не повторять уже названные слова!\n" +
		"   Игрок, в чьих руках бомба \"взорвалась\",\n" +
		"проигрывает раунд. Либо можно закончить\n" +
		"раунд принудительно, нажав среднюю кнопку\n" +
		"(кнопку с бомбой). Новый раунд можно начать\n" +
		"кликнув по игровому слогу в центре экрана.\n" +
		"   Нажмите на слово \"БОМБА\" и играйте!\n" +
		"   Веселой и многословной игры Вам! " + u'\u263a')

dark_theme_flag = True  # флаг задания темы оформления (True -> темная, False -> Светлая)
slow_rotation_flag = False  # режим медленного вращения
angle_increment = 0.25  # приращение угла поворота игровой надписи
game_world_list_len = len(game_world_list)  # длина списка слогов для отлова финального раунда
game_world_scale = 1.0  # масштабный коэффициент для размера шрифта игровой надписи
audio_loaded_sum = set()  # множество для фиксации флагов загрузки аудио дорожек
start_resolution_setflag = set()  # множество для флага разрешения старта раунда
angle_value = 0.0  # угол поворота игровой надписи
audio_volume = 1.0  # громкость звука в игре
# playing - воспроизведение аудио продолжается
# paused - нажата кнопка преждевременного окончания раунда (кнопка с бомбой)
# completed - воспроизведение аудио завершено (дошло до конца дорожки)
game_world_in_action = ""  # игровой слог текущего раунда
# audio_tik_state_value = ""  # текущее состояние воспроизведения аудио с тиканием:
# время старта игры
time_min = localtime().tm_min
time_min = str(time_min) if time_min >= 10 else ("0" + str(time_min))
start_time_date = datetime.now()  # (как объект time для расчета дельты)
start_time_str = (str(localtime().tm_hour) + ":" + time_min)  # (как строка формата ЧЧ:ММ)
seek_start_stop_flag = True  # флаг необходим, чтобы обойти стартовый вызов stop_round


def main(page: ft.Page):
	# ==== Ресурсы ====

	# звуковой эффект старта раунда
	audio_start = ft.Audio(
		src=f"/sounds/start_sound_effect.mp3",
		autoplay=False,
		on_loaded=lambda _: audio_loaded_sum.add(1),
		on_seek_complete=start_resolution_setflag.add(1),
	)
	page.overlay.append(audio_start)

	# def audio_tik_state_update(value):
	# 	global audio_tik_state_value
	# 	audio_tik_state_value = value

	# останов раунда
	def stop_round(_):
		global game_world_in_action, seek_start_stop_flag

		if seek_start_stop_flag:
			seek_start_stop_flag = not (seek_start_stop_flag)
			return None
		else:
			seek_start_stop_flag = not (seek_start_stop_flag)

		audio_tik.pause()
		audio_explosion.play()

		btn_help.disabled = False
		theme_btn.disabled = False
		dropdown_rotate.disabled = False
		page.floating_action_button.disabled = True
		sound_slider.disabled = False
		icon_btn_sound.disabled = False
		btn_game_world_down.disabled = False
		btn_game_world_up.disabled = False
		page.update()

		if len(game_world_list) == 0:  # если был последний раунд
			game_world.font_family = "Geologica"
			game_world.size = 50
			game_world.rotate = 0
			game_world.color = "red"
			game_world.value = "ИГРА\nОКОНЧЕНА"
			page.floating_action_button.visible = False
			dropdown_rotate.disabled = True
			page.update()
			return 0
		else:
			game_world.color = "red"
			game_world.spans = [
				ft.TextSpan(
					game_world_in_action,
					ft.TextStyle(
						decoration=ft.TextDecoration.LINE_THROUGH,
						decoration_thickness=2
					),
					on_click=start_round
				)
			]
			page.update()

	# поворот игровой надписи каждую секунду
	def rotate_game_world(_):
		global angle_value, angle_increment
		angle_value += angle_increment / 4 if slow_rotation_flag else angle_increment
		game_world.rotate = angle_value
		page.update()

	# звук тикания часов (в течение раунда)
	audio_tik = ft.Audio(
		src=f"/sounds/tik.mp3",
		autoplay=False,
		on_loaded=lambda _: audio_loaded_sum.add(2),
		on_position_changed=rotate_game_world,
		# on_state_changed=lambda e: audio_tik_state_update(e.data),
		on_seek_complete=stop_round,
		on_duration_changed=lambda e: print("Текущая позиция в аудиодорожке:", e.data),
	)
	page.overlay.append(audio_tik)

	# звук взрыва бомбы (окончание раунда)
	audio_explosion = ft.Audio(
		src=f"/sounds/explosion.wav",
		autoplay=False,
		on_loaded=lambda _: audio_loaded_sum.add(3),
	)
	page.overlay.append(audio_explosion)

	# звук теста громкости
	audio_test = ft.Audio(
		src=f"/sounds/test-volume.mp3",
		autoplay=False,
		on_loaded=lambda _: audio_loaded_sum.add(4),
	)
	page.overlay.append(audio_test)

	# иконка бомбочки
	img = ft.Image(
		src=f"/icons/loading-animation.png",
		width=30,
		height=30,
		fit=ft.ImageFit.FIT_HEIGHT,
	)

	page.fonts = {
		"Geologica": "/fonts/Geologica.ttf",
		"linux-libertine-underlined": "/fonts/linux-libertine-underlined.ttf",
		"octicons": "/fonts/octicons.ttf"
	}

	page.theme_mode = "LIGHT"

	# ==== Функции контролов ====

	def volume_down(_):
		audio_tik.volume -= 0.1
		audio_tik.update()

	def volume_up(_):
		audio_tik.volume += 0.1
		audio_tik.update()

	# разворачивание подсказки
	def w_help_show(_):
		delta_time_date = datetime.now() - start_time_date
		hours, seconds = divmod(int(delta_time_date.total_seconds()), 3600)
		minutes = seconds // 60

		bs_click_help.content = ft.Container(
			ft.Column(
				[ft.Text("НАЧАЛО ИГРЫ - " + start_time_str +
						 f"\nДЛИТЕЛЬНОСТЬ ИГРЫ - {hours:02}:{minutes:02}"),
				 ft.Text(help_text, font_family="octicons", size=13)
				 # ft.ElevatedButton("Закрыть подсказку", on_click=w_help_close)
				 ],
				tight=True,
				horizontal_alignment="center"
			),
			padding=5
		)
		bs_click_help.open = True
		bs_click_help.update()

	# смена темы
	def w_change_theme(_):
		global dark_theme_flag
		page.theme_mode = "dark" if dark_theme_flag else "light"
		dark_theme_flag = False if dark_theme_flag else True
		page.update()

	# выбор вращения
	def radio_item_changed(_):
		global angle_increment, angle_value
		if radio_group_rotate.value == "+":
			angle_increment = 0.25
		elif radio_group_rotate.value == "-":
			angle_increment = -0.25
		elif radio_group_rotate.value == "0":
			angle_value = 0.0
			angle_increment = 0.0
			game_world.rotate = 0
			slow_rotate_checker.checked = False
			page.update()
		else:
			angle_value = 1.57
			angle_increment = 0.0
			game_world.rotate = 1.57
			slow_rotate_checker.checked = False
			page.update()

	# установка/снятие чекбокса медленной скорости
	def slow_rotation_clicked(e):
		global slow_rotation_flag, angle_increment
		if angle_increment != 0.0:
			e.control.checked = not e.control.checked
			slow_rotation_flag = not slow_rotation_flag
		page.update()

	# изменение ползунка громкости
	def slider_changed(e):
		if e.control.value == 0:
			icon_btn_sound.icon = ft.icons.VOLUME_OFF_OUTLINED
			audio_start.volume = 0
			audio_tik.volume = 0
			audio_explosion.volume = 0

		elif e.control.value > 0:
			icon_btn_sound.icon = ft.icons.VOLUME_UP_OUTLINED
			audio_start.volume = audio_tik.volume = audio_explosion.volume = e.control.value * 0.01
			audio_test.volume = e.control.value * 0.01
			audio_test.play()
		page.update()

	# увеличение размера шрифта игрового слога
	def w_game_world_scale_up(_):
		global game_world_scale
		if game_world_scale <= 3:
			btn_game_world_down.disabled = False
			game_world_scale += 0.2
			game_world.scale = game_world_scale
			page.update()
		else:
			btn_game_world_up.disabled = True

	# уменьшение размера шрифта игрового слога
	def w_game_world_scale_down(_):
		global game_world_scale
		if game_world_scale >= 1:
			btn_game_world_up.disabled = False
			game_world_scale -= 0.2
			game_world.scale = game_world_scale
			page.update()
		else:
			btn_game_world_down.disabled = True

	# старт раунда
	def start_round(_):
		global game_world_in_action

		dropdown_rotate.disabled = True
		btn_help.disabled = True
		theme_btn.disabled = True
		dropdown_rotate.disabled = True
		sound_slider.disabled = True
		icon_btn_sound.disabled = True
		btn_game_world_down.disabled = True
		btn_game_world_up.disabled = True
		page.update()

		game_world.font_family = "linux-libertine-underlined"
		game_world.weight = ft.FontWeight.W_300
		game_world.scale = game_world_scale
		game_world.size = 150
		game_world.color = "green"
		game_world.value = ""

		game_world_in_action = choice(game_world_list)
		game_world_list.remove(game_world_in_action)
		game_world.spans = [
			ft.TextSpan(
				game_world_in_action,
				ft.TextStyle(
					decoration=ft.TextDecoration.NONE,
					decoration_thickness=1
				),
				on_click=lambda _: print("Поехали!!!!")
			)
		]
		page.update()

		audio_start.play()

		game_world.color = "blue"
		page.update()
		game_world.color = "red"
		page.update()
		sleep(0.25)
		game_world.color = "blue"
		page.update()
		sleep(0.25)
		game_world.color = "red"
		page.update()
		sleep(0.25)
		game_world.color = "green"
		page.update()
		sleep(0.25)
		page.floating_action_button.disabled = False
		page.update()

		sec_value = randint(3, 9)  # диапазон продолжительности раунда в секундах
		print(audio_tik.get_current_position())
		print(audio_tik.get_duration())
		audio_tik.seek(sec_value * 1000)
		audio_tik.resume()

	# page.update()

	# ==== Начальные настройки страницы и ее виджетов (описания для добавления на страницу) ====

	page.horizontal_alignment = page.vertical_alignment = "center"

	# кнопка для чтения правил
	btn_help = ft.IconButton(ft.icons.DEVICE_UNKNOWN_SHARP, on_click=w_help_show)

	# Нижняя выдвижная подсказка
	bs_click_help = ft.BottomSheet(
		ft.Container(
			ft.Column(
				[ft.Text("ПРОЧИТАЙТЕ ПОДСКАЗКУ "),
				 ft.Text(help_text,
						 font_family="octicons",
						 size=13
						 )
				 # ft.ElevatedButton("Закрыть подсказку", on_click=w_help_close)
				 ],
				tight=True,
				horizontal_alignment="center"
			),
			padding=5
		),
		open=True
	)

	# кнопка изменения темы (темная / светлая)
	theme_btn = ft.IconButton(ft.icons.BRIGHTNESS_4_OUTLINED, on_click=w_change_theme)

	# кнопка с выпадающем сдвоенным слайдером
	range_slider = ft.RangeSlider(
		min=0,
		max=50,
		start_value=10,
		divisions=10,
		end_value=20,
		inactive_color=ft.colors.GREEN_300,
		active_color=ft.colors.GREEN_700,
		overlay_color=ft.colors.GREEN_100,
		label="{value}%",
	)

	# a1 = ft.PopupMenuItem(icon=ft.icons.EXPLORE_SHARP, text="ПОДТВЕРДИТЬ")
	# a2 = ft.ElevatedButton(text="Submit", on_click=w_range_slider)
	#
	# # кнопка задания времени раунда (ПОКА НЕ РЕАЛИЗОВАНО)
	# dropdown_range_slider = ft.PopupMenuButton(
	# 	icon=ft.icons.EXPLORE_SHARP,
	# 	items=[
	# 		a1,
	# 		a2
	# 	]
	# )

	radio_group_rotate = ft.RadioGroup(content=ft.Column([
		ft.Radio(value="+", label="вращение  " + u'\u2b6e'),
		ft.Radio(value="-", label="вращение  " + u'\u2b6f'),
		ft.Radio(value="0", label="без вращ.   " + u'\u15c5'),
		ft.Radio(value="90", label="без вращ.   " + u'\u15c6')
	],
	), on_change=radio_item_changed)
	radio_group_rotate.value = "+"

	slow_rotate_checker = ft.PopupMenuItem(text=" Медленное вращение", checked=False,
										   on_click=slow_rotation_clicked)

	# кнопка с падающем меню для задания режима вращения игрового слога
	dropdown_rotate = ft.PopupMenuButton(
		icon=ft.icons.EXPLORE_SHARP,
		items=[
			radio_group_rotate,
			slow_rotate_checker
			# angle_confirm_btn
		]
	)

	# Верхняя панель
	page.appbar = ft.AppBar(
		title=ft.Text(" Игра «БОМБА»"),
		automatically_imply_leading=False,
		center_title=False,
		bgcolor=ft.colors.SURFACE_VARIANT,
		actions=[
			# dropdown_range_slider,  # еще не реализовано
			btn_help,  # кнопка правил
			theme_btn,  # кнопка переключения темы
			dropdown_rotate  # выбор вращения
		]
	)

	# центральная надпись (игровой слог)
	game_world = ft.Text(
		"",
		text_align=ft.TextAlign.CENTER,
		disabled=False,
		spans=[
			ft.TextSpan(
				"БОМБА",
				ft.TextStyle(
					# decoration=ft.TextDecoration.UNDERLINE,
					# decoration_thickness=3
					color="green"
				),
				on_click=start_round
			)
		]
	)

	game_world.font_family = "Geologica"
	game_world.size = 60

	icon_btn_sound = ft.IconButton(icon=ft.icons.VOLUME_UP_OUTLINED, icon_color=ft.colors.WHITE)

	sound_slider = ft.Slider(min=0, max=100, divisions=10, value=100, label="{value}%", width=90,
							 on_change=slider_changed)

	# кнопка-иконка уменьшения размера шрифта
	btn_game_world_down = ft.IconButton(icon=ft.icons.TEXT_DECREASE_ROUNDED,
										icon_color=ft.colors.WHITE,
										on_click=w_game_world_scale_down)
	# кнопка-иконка увеличения размера шрифта
	btn_game_world_up = ft.IconButton(icon=ft.icons.TEXT_INCREASE_SHARP,
									  icon_color=ft.colors.WHITE, on_click=w_game_world_scale_up)

	# Центральная кнопка (кнопка с бомбой)
	page.floating_action_button = ft.FloatingActionButton(
		content=ft.Row([img], alignment="center"),
		bgcolor=ft.colors.AMBER_200,
		shape=ft.RoundedRectangleBorder(radius=20),
		width=40,
		height=40,
		mini=True,
		on_click=stop_round)
	page.floating_action_button_location = ft.FloatingActionButtonLocation.CENTER_DOCKED
	page.floating_action_button.disabled = True

	# Нижняя панель
	page.bottom_appbar = ft.BottomAppBar(
		bgcolor=ft.colors.BLUE,
		shape=ft.NotchShape.CIRCULAR,
		height=70.0,
		content=ft.Row(
			controls=[
				icon_btn_sound,  # кнопка-иконка откл. звука
				sound_slider,  # ползунок громкости
				ft.Container(expand=True),  # разделитель серединный
				btn_game_world_down,  # кнопка-иконка уменьшения размера шрифта
				btn_game_world_up,  # кнопка-иконка увеличения размера шрифта
			]
		),
	)

	# ==== Добавление виджетов на страницу ====

	page.add(game_world, bs_click_help)

	# начало основонго кода
	global angle_value, angle_increment, game_world_list, game_world_list_len, \
		game_world_scale, game_world_in_action

	while sum(audio_loaded_sum) != 10:
		sleep(0.0002)
		print("Ждем загрузки звуков" + str(sum(audio_loaded_sum)))
		print("start_resolution_setflag = " + str(start_resolution_setflag))


# start_resolution_setflag.clear()
# главный цикл
# while True:
# 	# ждем нажатия на слово БОМБА или игровой слог
# 	while sum(start_resolution_setflag) == 0:
# 		sleep(2.5)
# 		print("Пока ждем")
# 		print("start_resolution_setflag = " + str(start_resolution_setflag))
#
# 	start_resolution_setflag.clear()
# 	print("start_resolution_setflag = " + str(start_resolution_setflag))


# angle_value += angle_increment / 4 if slow_rotation_flag else angle_increment
# game_world.rotate = angle_value
# page.update()


ft.app(target=main, assets_dir="assets")
